package com.example.demo.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;

@Service
public class ProductRepository {

	@Autowired
	MongoClient mongoClient;
	
	@Value("${datastore.mongo.dbname}")
	String dbName;
	
	@Value("${datastore.mongo.collection}")
	String collection;
	
	public String getProductPriceById(String productId) {
		DBCollection table = mongoClient.getDB(dbName).getCollection(collection);
		
		BasicDBObject obj = new BasicDBObject();
		obj.put("productid", productId);
		
		DBCursor cursor = table.find(obj);
		while(cursor.hasNext()) {
			return cursor.next().toString();
		}

		return null;
	}
	
/*	public static void main(String[] args) throws Exception{
		ProductRepository repo = new ProductRepository();
		repo.collection="product";
		repo.dbName="local";
		repo.mongoClient = new MongoClient("localhost", 27017);
		System.out.println(repo.getProductPriceById("13860428"));
		
	}*/
	
	
	/*public static void main(String[] args) throws Exception {
		MongoClient mongo = new MongoClient( "localhost" , 27017 );
		System.out.println(mongo.getDatabaseNames());
		System.out.println(mongo.getDB("local").getCollectionNames());	
		
		DBCollection table = mongo.getDB("local").getCollection("product");
		BasicDBObject document = new BasicDBObject();
		document.put("productid", "13860429");
		document.put("name", "The Big Lebowski (Blu-ray) (Widescreen)");
		
		document.put("current_price", 13.49);
		document.put("currency_code", "USD");
		table.insert(document);
		
		System.out.println(mongo.getDB("local").getCollectionNames());
	}*/
	
}
