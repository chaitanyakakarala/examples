package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.ProductInventory;
import com.google.gson.Gson;

@RestController
public class ProductController {

	@Autowired
	ProductInventory inventory;
	
	@RequestMapping(method = RequestMethod.GET , path = "/products/{id}")
	public ResponseEntity<String> viewProductDetails(@PathVariable(name = "id" , required = true) String id) {
		
		return ResponseEntity.status(HttpStatus.OK)
							.body(new Gson().toJson(inventory.getProductDetails(id)));
	}
	
}
