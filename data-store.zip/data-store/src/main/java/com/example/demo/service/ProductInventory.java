package com.example.demo.service;

import com.example.demo.entity.ProductEntity;

public interface ProductInventory {

	ProductEntity getProductDetails(String id);
	
}
