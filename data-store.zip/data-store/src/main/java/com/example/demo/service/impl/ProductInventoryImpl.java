package com.example.demo.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.example.demo.entity.ProductEntity;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.ProductInventory;
import com.example.demo.util.DataStoreUtil;

@Service
public class ProductInventoryImpl implements ProductInventory{

	@Value("${datastore.prod.json.path}")
	String jsonPath;
	
	@Value("${datastore.prod.json.path.current_price}")
	String currentPrice;
	
	@Value("${datastore.prod.json.path.currency}")
	String currencyCode;
	
	@Autowired
	ProductRepository repository;
	
	@Override
	public ProductEntity getProductDetails(String id) {
		
		Map<String,String> obj = new HashMap<String,String>(3);
		
		try {
			
			String jsonForName = FileUtils.readFileToString(new ClassPathResource("data.json").getFile(), "UTF-8");
			String jsonForPrice = repository.getProductPriceById(id);
			
			Map<String,String> current_price = new HashMap<String,String>(2);
			if(null != jsonForPrice) {
				current_price.put("current_price", DataStoreUtil.calculateJsonPath(jsonForPrice, currentPrice).toString());
				current_price.put("currency_code", DataStoreUtil.calculateJsonPath(jsonForPrice, currencyCode).toString());	
			}

			ProductEntity entity = new ProductEntity();
			entity.setId(id);
			entity.setName(DataStoreUtil.calculateJsonPath(jsonForName, jsonPath));
			entity.setCurrent_price(current_price);
			
			return entity;
			
		}catch(Exception exp) {
			System.err.println(exp);
			throw new RuntimeException(exp.getMessage());
		}
		
	}

}
