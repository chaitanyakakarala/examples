package com.kc.demo.util;

import java.util.List;

public class GenericFileUtil {

    public static List<String> repeatSplitWithSeperator(String item, List<String> result) {
        String temp = null;
        if (null != item && item.indexOf(",") >0  ){
            temp = item.substring(0,item.indexOf(","));
            item = item.substring(item.indexOf(",")+1);
            result.add(temp);

        }else if (null != item && !item.isEmpty()){
            result.add(item);
            item = "";
        }

        if (0 != item.length()){
            repeatSplitWithSeperator(item,result);
        }
        return result;
    }

    public static boolean isNaN(String input){
        String numbers = "0123456789";
        if (null == input || input.isEmpty())
            return false;

        for (int i = 0;i< input.length();i++) {
            if (numbers.indexOf(input.charAt(i)) == -1) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        System.out.println(isNaN(""));
        System.out.println(isNaN("erwesdf"));
        System.out.println(isNaN("23849023"));
    }
}
