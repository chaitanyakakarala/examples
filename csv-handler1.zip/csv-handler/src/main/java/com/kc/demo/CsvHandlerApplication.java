package com.kc.demo;

import com.kc.demo.factory.FileHandlerFactory;
import com.kc.demo.service.Operations;
import com.kc.demo.util.GenericFileUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class CsvHandlerApplication {

    public static void main(String[] args) {
        //2147483647 is the max value

        //1.Streamify elements and store into collections using lambda + streams
        List<List> lists = FileHandlerFactory.getFileHandler("csv")
                .readFiletoCollection("test.csv")
                .stream()
                .filter(line -> !line.isEmpty() && line.contains(","))
                .map(item -> GenericFileUtil.repeatSplitWithSeperator(item, new ArrayList<String>()))
                .collect(Collectors.toList());

        //2.Get Elements those required from objects
        Operations operations = new Operations(lists);
        String userInput =  operations.displayConsole();
        operations.recursiveCall(userInput);
    }

}
