package com.kc.demo.service;

import java.util.List;

public interface ItemRepository {

    List<List> getAllElements();

    List<String> getRowById(int index) ;

    String getSpecificElementFromRow(int rowIndex,int itemindex);
}
