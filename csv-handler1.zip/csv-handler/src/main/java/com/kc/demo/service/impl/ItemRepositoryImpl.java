package com.kc.demo.service.impl;

import com.kc.demo.service.ItemRepository;

import java.util.List;

public class ItemRepositoryImpl implements ItemRepository{

    private List<List> rowElements = null;
    private int sizeOfRows = 0;

    public ItemRepositoryImpl(List<List> rowElements) {
        this.rowElements = rowElements;
        if (null != rowElements && !rowElements.isEmpty()) {
            this.sizeOfRows = rowElements.size();
        }
    }

    @Override
    public List<List> getAllElements() {
        if (null != rowElements && !rowElements.isEmpty()) {
            this.sizeOfRows = rowElements.size();
            return rowElements;
        }else {
            throw new RuntimeException("Collection provided after reading file is Empty");
        }
    }

    @Override
    public List<String> getRowById(int index) {
        if (index < sizeOfRows) {
            return getAllElements().get(index);
        } else {
            throw new RuntimeException(String.format("Specified Row Index %s not exists in " +
                    "collection provided",index));
        }
    }

    @Override
    public String getSpecificElementFromRow(int rowIndex, int itemindex) {
        List<String> rowElements = getRowById(rowIndex);
        if (itemindex < rowElements.size()) {
            return getRowById(rowIndex).get(itemindex);
        }else {
            throw new RuntimeException(String.format("Specified Element in index %s is " +
                    "not exist in row %s",itemindex,rowIndex));
        }

    }
}
