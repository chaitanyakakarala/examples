package com.kc.demo.pojo;

import java.util.ArrayList;
import java.util.List;

public class FileContent {

    private List<List> lines = new ArrayList<List>(0);

}
