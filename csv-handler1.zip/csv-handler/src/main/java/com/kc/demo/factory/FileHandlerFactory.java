package com.kc.demo.factory;

import com.kc.demo.service.FileHandler;
import com.kc.demo.service.impl.CsvFileHandler;

public class FileHandlerFactory {

    public static FileHandler getFileHandler(String type) {
        switch (type){
            default:
                return new CsvFileHandler();
        }
    }

}
