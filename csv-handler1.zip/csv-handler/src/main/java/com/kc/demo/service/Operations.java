package com.kc.demo.service;

import com.kc.demo.service.impl.ItemRepositoryImpl;
import com.kc.demo.util.GenericFileUtil;

import java.util.List;
import java.util.Scanner;

public class Operations {

    private ItemRepository itemRepository;

    public Operations(List<List> fileElements) {
        this.itemRepository = new ItemRepositoryImpl(fileElements);
    }

    public String displayConsole() {
        System.out.println("Reading the file completed and present in memory");
        System.out.println("Please Enter the as per below options for requred Operation");
        System.out.println("Press 1 for List All Rows and elements as list");
        System.out.println("Press 2 for elements of a partular row list");
        System.out.println("Press 3 for particular element in a row");
        System.out.println("Press 5 to exit program");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        return input;
    }

    public void doOperationForRow() {
        System.out.println("Please enter row index as integer");
        Scanner scanner = new Scanner(System.in);
        String rowindex = scanner.nextLine();
        if (GenericFileUtil.isNaN(rowindex)) {
            System.out.println();
            try{
                System.out.println("Below is requested row from csv \n"+itemRepository.getRowById(Integer.parseInt(rowindex)-1));
            }catch (Exception exp) {
                exp.printStackTrace();
                System.err.println(exp.getLocalizedMessage());
            }
        } else {
            System.err.println("Please pass numeric value for row index");
        }
    }

    public void doOperationForElement() {
        System.out.println("Please enter row index as integer");
        Scanner scaner = new Scanner(System.in);
        String rowIndx = scaner.nextLine();
        if (!GenericFileUtil.isNaN(rowIndx)) {
            System.err.println("Please pass numeric value for row index");
        }
        System.out.println("Please enter Column index as integer");
        String colIndx = scaner.nextLine();
        if (!GenericFileUtil.isNaN(colIndx)) {
            System.err.println("Please pass numeric value for column index");
        }
        try{
            System.out.println(itemRepository.getSpecificElementFromRow(Integer.parseInt(rowIndx)-1,
                    Integer.parseInt(colIndx)-1));
        }catch (Exception exp) {
            System.out.println(exp.getLocalizedMessage());
        }

    }

    public void doOperation(String input) {
        switch (input.trim().toUpperCase()) {
            case "1" :
                System.out.println("Below is list of complete rows and elements");
                itemRepository.getAllElements().forEach(item -> System.out.println(item));
                break;
            case "2" :
                doOperationForRow();
                break;
            case "3" :
                doOperationForElement();
                break;
            case "5" :
                break;
            default :
                System.err.println("Please pass case as mentioned ");
                break;
        }

    }

    public void recursiveCall( String input) {
        try{
            doOperation(input);
            while (!"5".equals(input.trim())) {
                input = displayConsole();
                doOperation(input);
            }
        }catch (Exception exception) {
            System.err.println(exception.getLocalizedMessage());
        }
    }

}
