##Starting mongo db on the fly without service.
##mongod --dbpath=D:/mongodb/data/ --storageEngine=mmapv1

##db.product.find({"productid":"13860428"}) --list the product by id
##db.product.insert({"productid":"testid"})

##Monja DB
