package com.store.demo;

public class TestAppConfig {

}
