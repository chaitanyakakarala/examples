package com.store.demo;

public class DataStoreApplicationTests {

	public void contextLoads() {
	}

}
