package com.kc.demo.service;

import java.util.List;

public interface FileHandler {

	List<String> readFiletoCollection(String filePath);
	
}
