package com.kc.demo;

import java.util.List;

import com.kc.demo.service.FileHandler;
import com.kc.demo.service.impl.CsvFileHandler;


public class CsvHandlerApplication {

/*	public static void main(String[] args) {
		List<String> lines =  new ArrayList<String>();
		try(
				FileReader reader = new FileReader(new File("test.csv"));
				BufferedReader br = new BufferedReader(reader);
			){
			String currentLine = null;
			while(null != (currentLine = br.readLine()) ){
				lines.add(currentLine);
			}
			Files.readAllLines(Paths.get("test.csv"))
				 .stream()
				 .collect(Collectors.toList());
		}catch(Exception exp) {
			exp.printStackTrace();
		}
		System.out.println(lines);
	}*/
	
	private static FileHandler fileHandler = new CsvFileHandler();
	
	public static void main(String[] args) {
		List<String> lines = fileHandler.readFiletoCollection("test1.csv");
		System.out.println(lines);
	}
	
	
	
}
